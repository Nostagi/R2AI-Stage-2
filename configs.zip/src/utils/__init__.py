"""Helper functions & common utilities."""
